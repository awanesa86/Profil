import React from 'react';


const Points = () => {

      return (
    <div className="noted">
      <h2 className="text-xl font-bold mb-4">coming soon</h2>
    </div>
  );
};


export default Points;