import React, { useState } from 'react';

// Card 1
const NotificationCard1 = () => (
  <div className="bg-[#FEE4C4] p-4 flex gap-4 w-full">
    {/* Icon gambar */}
    <div className="relative w-12 h-12 shrink-0">
      <img src="./img/frame1.png" alt="notif" className="w-full h-full object-cover" />
    </div>

    {/* Konten utama */}
    <div className="flex justify-between items-start w-full gap-4">
      {/* Teks kiri */}
      <div className="flex-1">
        <h3 className="font-bold text-lg">Workshop Event Cancelled!</h3>
        <p className="text-sm text-gray-800 mt-1">
          We regret to inform you that the <strong>"Make Your Own Paper Wayang"</strong> scheduled
          for 14:00 on September 11th, 2001 has been cancelled.
        </p>
      </div>

      {/* Kolom kanan: tanggal & See More */}
      <div className="flex flex-col items-end min-w-fit text-sm text-gray-700 whitespace-nowrap">
        <p className="mb-8">14:00 | April, 11th, 2025</p>
        <a href="#" className="text-black font-semibold underline">
          See More
        </a>
      </div>
    </div>
  </div>
);



// Card 2
const NotificationCard2 = () => (
  <div className="bg-[#FCEDDA] p-4 flex gap-4 w-full">
    {/* Icon gambar */}
    <div className="relative w-12 h-12 shrink-0">
      <img src="./img/frame2.png" alt="notif" className="w-full h-full object-cover" />
    </div>

    {/* Konten utama */}
    <div className="flex justify-between items-start w-full gap-4">
      {/* Teks kiri */}
      <div className="flex-1">
        <h3 className="font-bold text-lg">New Forum Reply</h3>
        <p className="text-sm text-gray-800 mt-1">
          Someone just replied to your post in the <strong>"What should I bring to a pottery workshop?"</strong> thread. Check it out and join the conversation.
        </p>
      </div>

      {/* Kolom kanan: tanggal & See More */}
      <div className="flex flex-col items-end min-w-fit text-sm text-gray-700 whitespace-nowrap">
        <p className="mb-8">14:00 | April, 11th, 2025</p>
        <a href="#" className="text-black font-semibold underline">
          See More
        </a>
      </div>
    </div>
  </div>
);

// Unseen wrapper
const UnseenNotification = () => (
  <div className="space-y-0">
    <NotificationCard1 />
    <NotificationCard2 />
  </div>
);

// Main Notification component
const Notification = () => {
  const [tab, setTab] = useState('unseen');

  return (
    <div className="w-full max-w-4xl mx-auto mt-1">
      {/* Tabs */}
      <div className="mb-4">
        <button
          onClick={() => setTab('unseen')}
          className={`px-4 py-2 font-semibold border-b-2 ${
            tab === 'unseen' ? 'border-black text-black' : 'border-transparent text-black'
          }`}
        >
          Unseen
        </button>
        <button
          onClick={() => setTab('seen')}
          className={`px-4 py-2 font-semibold border-b-2 ${
            tab === 'seen' ? 'border-black text-black' : 'border-transparent text-black'
          }`}
        >
          Seen
        </button>
      </div>

      {/* Content */}
      {tab === 'unseen' && <UnseenNotification />}
      {tab === 'seen' && <div>Seen notification goes here</div>}
    </div>
  );
};

export default Notification;
